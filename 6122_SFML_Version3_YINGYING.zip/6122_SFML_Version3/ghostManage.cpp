//
//  ghostManage.cpp
//  6122_SFML_Version3
//
//  Created by Jiahao Sun on 2022/10/22.
//  Copyright © 2022 Jiahao Sun. All rights reserved.
//

#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <string>
#include <vector>
#include <numeric>
#include <cmath>
#include <math.h>
#include <iostream>

#include "globalVariable.h"

using namespace sf;
using namespace std;

int * ghostManage(sf::RenderWindow& gameWindow, int pacmanPositionX, int pacmanPositionY, Time dt)
{
    int message1;
    int message2;
    static int ghostOutput[2] = {message1, message2};
    
    // Prepare the blue ghost
    Texture textureBlueGhost;
    textureBlueGhost.loadFromFile("graphics/blue_ghost.bmp");
    Sprite spriteBlueGhost;
    spriteBlueGhost.setTexture(textureBlueGhost);
    //spriteBlueGhost.setPosition(1000, 0);
    
    // Prepare the orange ghost
    Texture textureOrangeGhost;
    textureOrangeGhost.loadFromFile("graphics/orange_ghost.bmp");
    Sprite spriteOrangeGhost;
    spriteOrangeGhost.setTexture(textureOrangeGhost);
    //spriteOrangeGhost.setPosition(1000, 0);
    
    // Prepare the pink ghost
    Texture texturePinkGhost;
    texturePinkGhost.loadFromFile("graphics/pink_ghost.bmp");
    Sprite spritePinkGhost;
    spritePinkGhost.setTexture(texturePinkGhost);
    //spritePinkGhost.setPosition(1000, 0);
    
    // Prepare the red ghost
    Texture textureRedGhost;
    textureRedGhost.loadFromFile("graphics/red_ghosts.bmp");
    Sprite spriteRedGhost;
    spriteRedGhost.setTexture(textureRedGhost);
    //spriteRedGhost.setPosition(1000, 0);
    /*
    // Draw ghosts
    gameWindow.draw(spriteBlueGhost);
    gameWindow.draw(spriteOrangeGhost);
    gameWindow.draw(spritePinkGhost);
    gameWindow.draw(spriteRedGhost);
    */
    if ((pacmanPositionX == 1000) && (pacmanPositionY == 0))
    {
        spriteBlueGhost.setPosition(1000, 0);
        spriteOrangeGhost.setPosition(1000, 0);
        spritePinkGhost.setPosition(1000, 0);
        spriteRedGhost.setPosition(1000, 0);
        
    }
    else if (!ghostActive)
    {
        // How fast is the cloud
        srand((int)time(0) * 10);
        ghostSpeed = (rand() % 200);
        
        spriteBlueGhost.setPosition(303, 246);
        spriteOrangeGhost.setPosition(303, 246);
        spritePinkGhost.setPosition(303, 246);
        spriteRedGhost.setPosition(303, 246);
        ghostActive = true;
    }
    else
    {
        spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x + (ghostSpeed * dt.asSeconds()), spriteBlueGhost.getPosition().y);
        //gameWindow.draw(spriteBlueGhost);
        cout << "blue ghost position is " << spriteBlueGhost.getPosition().x << " " << spriteBlueGhost.getPosition().y << "\n";
    }

    // Draw ghosts
    gameWindow.draw(spriteBlueGhost);
    gameWindow.draw(spriteOrangeGhost);
    gameWindow.draw(spritePinkGhost);
    gameWindow.draw(spriteRedGhost);
    
    return ghostOutput;
}
