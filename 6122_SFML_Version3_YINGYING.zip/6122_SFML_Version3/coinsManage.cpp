//
//  coinsManage.cpp
//  6122_SFML_Version3
//
//  Created by Jiahao Sun on 2022/10/21.
//  Copyright © 2022 Jiahao Sun. All rights reserved.
//

#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <string>
#include <vector>
#include <numeric>
#include <cmath>
#include <math.h>
#include <iostream>

#include "globalVariable.h"

using namespace sf;
using namespace std;

int * coinsManage(sf::RenderWindow& gameWindow, int pacmanPositionX, int pacmanPositionY)
{
    int message1;
    int message2;
    static int coinsOutput[2] = {message1, message2};
    
    //pacmanMap = mapGenerate();
    
    
    sf::CircleShape shape(2.f);
    shape.setFillColor(sf::Color::White);
    //shape.setPosition(pacmanPositionXArray[1], pacmanPositionYArray[1]);
    sf::CircleShape shape2(5.f);
    shape2.setFillColor(sf::Color::White);
    
    sf::Text messageText;
    sf::Font font;
    font.loadFromFile("sansation.ttf");
    messageText.setFont(font);
    //messageText.setString("POWER UP");
    messageText.setCharacterSize(20);
    messageText.setFillColor(Color::White);
    // Position the text
    FloatRect textRect = messageText.getLocalBounds();

    messageText.setOrigin(textRect.left +
        textRect.width / 2.0f,
        textRect.top +
        textRect.height / 2.0f);
    
    messageText.setPosition(260, 312);
    gameWindow.draw(messageText);
    
    for(int row = 1; row < 30; row++)
    {
        // make a
        for(int col = 1; col < 27; col++)
        {
            if ((pacmanPositionX == pacmanPositionXArray[col - 1]) && (pacmanPositionY == pacmanPositionYArray[row - 1]) && (pacmanMap[row][col] == 0))
            {
                pacmanMap[row][col] = 2;
                collectedCoins++;
            }
            /*
             if pacman eats power up
             return coinsOutput = eatPowerup
             */
            else if ((pacmanPositionX == pacmanPositionXArray[col - 1]) && (pacmanPositionY == pacmanPositionYArray[row - 1]) && (pacmanMap[row][col] == 3))
            {
                pacmanMap[row][col] = 4;
                timePowerUpRemaining = 5;
            }
            else if (pacmanMap[row][col] == 0)
            {
                shape.setFillColor(sf::Color::White);
                shape.setPosition(pacmanPositionXArray[col - 1] + 15, pacmanPositionYArray[row - 1] + 15);
                gameWindow.draw(shape);
            }
            else if (pacmanMap[row][col] == 3)
            {
                shape2.setFillColor(sf::Color::White);
                shape2.setPosition(pacmanPositionXArray[col - 1] + 15, pacmanPositionYArray[row - 1] + 15);
                gameWindow.draw(shape2);
            }
        }
    }
    /*
    if (timePowerUpRemaining > 0)
    {
        messageText.setString("POWER UP");
        gameWindow.draw(messageText);
    }
    if (timePowerUpRemaining == 0)
    {
        messageText.setString("NOT POWER UP");
        gameWindow.draw(messageText);
    }*/
    
    if ((timePowerUpRemaining < 5) && (timePowerUpRemaining > 4))
    {
        messageText.setString("POWER UP 5");
        gameWindow.draw(messageText);
    }
    else if ((timePowerUpRemaining < 4) && (timePowerUpRemaining > 3))
    {
        messageText.setString("POWER UP 4");
        gameWindow.draw(messageText);
    }
    else if ((timePowerUpRemaining < 3) && (timePowerUpRemaining > 2))
    {
        messageText.setString("POWER UP 3");
        gameWindow.draw(messageText);
    }
    else if ((timePowerUpRemaining < 2) && (timePowerUpRemaining > 1))
    {
        messageText.setString("POWER UP 2");
        gameWindow.draw(messageText);
    }
    else if ((timePowerUpRemaining < 1) && (timePowerUpRemaining > 0))
    {
        messageText.setString("POWER UP 1");
        gameWindow.draw(messageText);
    }
    
    if (gameOver)
    {
        messageText.setString("GAME OVER");
        gameWindow.draw(messageText);
    }
    
    if (gameWin)
    {
        messageText.setString("YINGYING WIN");
        gameWindow.draw(messageText);
    }
    
    /*
    for(int col = 1; col < 27; col++)
    {
        if (pacmanMap[29][col] == 0){
            shape.setFillColor(sf::Color::White);
            shape.setPosition(pacmanPositionXArray[col], pacmanPositionYArray[28]);
            gameWindow.draw(shape);
        }
        else if (pacmanMap[29][col] == 3)
        {
            shape2.setFillColor(sf::Color::White);
            shape2.setPosition(pacmanPositionXArray[col], pacmanPositionYArray[28]);
            gameWindow.draw(shape2);
        }
    }
    
    for(int row = 1; row < 30; row++)
    {
        if (pacmanMap[row][26] == 0){
            shape.setFillColor(sf::Color::White);
            shape.setPosition(pacmanPositionXArray[25], pacmanPositionYArray[row]);
            gameWindow.draw(shape);
        }
        else if (pacmanMap[row][26] == 3)
        {
            shape2.setFillColor(sf::Color::White);
            shape2.setPosition(pacmanPositionXArray[25], pacmanPositionYArray[row]);
            gameWindow.draw(shape2);
        }
    }*/
    
    return coinsOutput;
}
