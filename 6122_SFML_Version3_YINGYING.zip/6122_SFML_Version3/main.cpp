/*
Author: Jiahao Sun
Class: ECE6122 QSZ
Last Date Modified: 10/17/2022
Description:
 This is a Pacman Game
 
 • Display the provided pac-man.bmp at the start of the game with the extra text
     o PRESS ENTER TO START
  in the middle of the window.
 • Once the user presses the ENTER key the game starts with
     o pacman located as shown above
     o all four ghosts start at the same location as shown above (bitmaps provided)
     o place the four power ups as shown above
     o place the coins as shown above
 
 • The ghost’s initial direction is determined randomly and when a ghost hits a wall
 its new direction is chosen randomly.
 • Control the location of pacman using the left, right, up, down arrow keys. • (~10 pts) Determine a game speed that makes the game fun to play (not too slow and not to
 fast)
 • The game ends when
     o one of the ghosts comes in contact with a non-powered up pacman
     o pacman consumes all the coins
     o user presses the escape key.
 • When pacman eats a powerup he can eat ghosts for 5 seconds. Ghosts that are
 eaten are gone forever.
 • Pacman and the ghost cannot go through walls.
 • Pacman and the ghost can go through the middle tunnels on each side.
 • You do not have to handle resizing the window. Just use the image size.
*/

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <numeric>
#include <cmath>
#include <sstream>
#include <thread>
#include <chrono>
#include <ctime>
#include <fstream>
#include <math.h>

using namespace sf;
using namespace std;

#include "globalVariable.h"
#include "mapGenerate.cpp"
#include "interactCheck.cpp"
#include "positionTranslate.cpp"
#include "ghostPositionTranslate.cpp"
#include "coinsManage.cpp"
//#include "ghostManage.cpp"

int main(int argc, char const** argv)
{
    // Create the main window
    //sf::RenderWindow window(sf::VideoMode(641, 728), "SFML window");
    sf::RenderWindow window(sf::VideoMode(1600, 1800), "SFML window");

    // Track whether the game is running
    bool paused = true;

    // Load a sprite to display
    sf::Texture textureBackground;
    if (!textureBackground.loadFromFile("graphics/maze.bmp"))
    {
        return EXIT_FAILURE;
    }
    
    /*
    constexpr unsigned char CELL_SIZE = 16;
    Sprite spriteCoins;
    spriteCoins.setTextureRect(sf::IntRect(0, CELL_SIZE, CELL_SIZE, CELL_SIZE));
     */
    
    // Create a sprite
    sf::Sprite spriteBackground;
    
    // Attach the texture to the sprite
    spriteBackground.setTexture(textureBackground);

    // Set the spriteBackground to cover the screen
    spriteBackground.setPosition(0, 0);

    // Make a pacman sprite
    Texture texturePacman;
    texturePacman.loadFromFile("graphics/pacman.bmp");
    Sprite spritePacman;
    spritePacman.setTexture(texturePacman);
    spritePacman.setPosition(1000, 0);
    
    // Is the pacman currently moving?
    bool pacmanActive = false;

    // How fast can the pacman run
    float pacmanSpeed = 0.0f;

    // Prepare the blue ghost
    Texture textureBlueGhost;
    textureBlueGhost.loadFromFile("graphics/blue_ghost.bmp");
    Sprite spriteBlueGhost;
    spriteBlueGhost.setTexture(textureBlueGhost);
    //spriteBlueGhost.setPosition(1000, 0);
    
    // Prepare the orange ghost
    Texture textureOrangeGhost;
    textureOrangeGhost.loadFromFile("graphics/orange_ghost.bmp");
    Sprite spriteOrangeGhost;
    spriteOrangeGhost.setTexture(textureOrangeGhost);
    //spriteOrangeGhost.setPosition(1000, 0);
    
    // Prepare the pink ghost
    Texture texturePinkGhost;
    texturePinkGhost.loadFromFile("graphics/pink_ghost.bmp");
    Sprite spritePinkGhost;
    spritePinkGhost.setTexture(texturePinkGhost);
    //spritePinkGhost.setPosition(1000, 0);
    
    // Prepare the red ghost
    Texture textureRedGhost;
    textureRedGhost.loadFromFile("graphics/red_ghosts.bmp");
    Sprite spriteRedGhost;
    spriteRedGhost.setTexture(textureRedGhost);
    //spriteRedGhost.setPosition(1000, 0);
    
    // Show PRESS ENTER TO START text
    sf::Text messageText;
    sf::Text scoreText;

    // We need to choose a font
    sf::Font font;
    font.loadFromFile("sansation.ttf");

    // Set the font to our message
    messageText.setFont(font);
    scoreText.setFont(font);

    // Assign the actual message
    messageText.setString("PRESS ENTER TO START");
    scoreText.setString("Score = 0");

    // Make it really big
    messageText.setCharacterSize(40);
    scoreText.setCharacterSize(40);

    // Choose a color
    messageText.setFillColor(Color::White);
    scoreText.setFillColor(Color::White);

    // Position the text
    FloatRect textRect = messageText.getLocalBounds();

    messageText.setOrigin(textRect.left +
        textRect.width / 2.0f,
        textRect.top +
        textRect.height / 2.0f);

    messageText.setPosition(320 / 1.0f, 360 / 1.0f);
    
    // Variables to control time itself
    Clock clock;
    
    //Sound
    SoundBuffer winBuffer;
    winBuffer.loadFromFile("yingying.wav");
    Sound win;
    win.setBuffer(winBuffer);
    //death.play();
    
    // Map related parameter preparation
    // Generate map in vector
    pacmanMap = mapGenerate();
    
    /*
    for(int i = 1; i < 26 + 1; i++)
    {
        pacmanPositionXArray[i - 1] = 43 + (i - 1) * (555 - 43) / 26;
        cout << pacmanPositionXArray[i - 1] << ", ";
    }
    cout << "\n";
    
    for(int i = 1; i < 26 + 1; i++)
    {
        pacmanPositionColumnArray[i - 1] = i;
        cout << pacmanPositionColumnArray[i - 1] << ", ";
    }
    cout << "\n";
    
    for(int i = 1; i < 29 + 1; i++)
    {
        pacmanPositionYArray[i - 1] = 40 + (i - 1) * (555 - 43) / 26;
        cout << pacmanPositionYArray[i - 1] << ", ";
    }
    cout << "\n";
    
    for(int i = 1; i < 29 + 1; i++)
    {
        pacmanPositionRowArray[i - 1] = i;
        cout << pacmanPositionRowArray[i - 1] << ", ";
    }
    cout << "\n";
    */
    
    //cout << "pacmanMap[0][0] = " << pacmanMap[0][0] << "\n";
    //cout << "pacmanMap[1][1] = " << pacmanMap[1][1] << "\n";

    // Start the game loop
    while (window.isOpen())
    {
        // Process events
        sf::Event event;
        while (window.pollEvent(event))
        {
            // Close window: exit
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            // Escape pressed: exit
            if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape) {
                window.close();
            }
        }
        
        /*
        ****************************************
        Handle the players input
        ****************************************
        */
        // Start the game
        if (Keyboard::isKeyPressed(Keyboard::Return))
        {
            paused = false;

            // Reset the time and the score
            //score = 0;
            //timeRemaining = 6;

            // pacman initial position
            //spritePacman.setPosition(321 - 18, 364 - 17 + 145);
            spritePacman.setPosition(303, 492);

            /*
            // ghosts initial position
            spriteBlueGhost.setPosition(321 - 18, 364 - 17 - 101);
            spriteOrangeGhost.setPosition(321 - 18, 364 - 17 - 101);
            spritePinkGhost.setPosition(321 - 18, 364 - 17 - 101);
            spriteRedGhost.setPosition(321 - 18, 364 - 17 - 101);
             */

            //acceptInput = true;
        }
        Time dt = clock.restart();
        pacmanSpeed = 100;
        
        if (timePowerUpRemaining > 0)
        {
            timePowerUpRemaining -= dt.asSeconds();
        }

        //cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
        //cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n" << "\n";
        
        //cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
        
        //cout << "dt.asSeconds() = " << dt.asSeconds() * pacmanSpeed << "\n";
        //cout << "timePowerUpRemaining = " << timePowerUpRemaining << "\n";
        
        if (Keyboard::isKeyPressed(Keyboard::Right) && !Keyboard::isKeyPressed(Keyboard::Left) && !Keyboard::isKeyPressed(Keyboard::Up) && !Keyboard::isKeyPressed(Keyboard::Down))
        {
            
            pacmanCoordinationRow = positionTranslate(23, 13, spritePacman.getPosition().x, spritePacman.getPosition().y)[0];
            pacmanCoordinationColumn = positionTranslate(23, 13, spritePacman.getPosition().x, spritePacman.getPosition().y)[1];

            /*
            //cout << "dt.asSeconds() = " << dt.asMicroseconds() * pacmanSpeed << "\n";
            cout << "Right " << "\n";
            cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
            cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n";
            
            cout << "pacmanCoordinationColumn = " << pacmanCoordinationColumn << "\n";
            cout << "pacmanCoordinationRow = " << pacmanCoordinationRow << "\n";
            
            cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
            cout << "Right is " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn + 1] << "\n";
            cout << "interactCheck = " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 1)[0] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 1)[1] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 1)[2] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 1)[3] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 1)[4] << "\n";
             */
            
            if (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 1)[0])
            {
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y);
                //cout << "situation 1" << "\n";
            }
            else if (spritePacman.getPosition().x == 641)
            {
                spritePacman.setPosition(0, spritePacman.getPosition().y);
            }
            else if (!interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 1)[3])
            {
                spritePacman.setPosition(spritePacman.getPosition().x + 0.25, pacmanPositionYArray[pacmanCoordinationRow - 1]);
                //cout << "situation 3" << "\n";
            }
            else
            {
                spritePacman.setPosition(spritePacman.getPosition().x + 0.25, spritePacman.getPosition().y);
                
                //cout << "situation 2" << "\n";
            }
            //cout << "\n";
        }
        
        if (!Keyboard::isKeyPressed(Keyboard::Right) && Keyboard::isKeyPressed(Keyboard::Left) && !Keyboard::isKeyPressed(Keyboard::Up) && !Keyboard::isKeyPressed(Keyboard::Down))
        {
            pacmanCoordinationRow = positionTranslate(23, 13, spritePacman.getPosition().x, spritePacman.getPosition().y)[0];
            pacmanCoordinationColumn = positionTranslate(23, 13, spritePacman.getPosition().x, spritePacman.getPosition().y)[1];
            /*
            cout << "Left " << "\n";
            cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
            cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n";
            
            cout << "pacmanCoordinationColumn = " << pacmanCoordinationColumn << "\n";
            cout << "pacmanCoordinationRow = " << pacmanCoordinationRow << "\n";
            
            cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
            cout << "Left is " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn - 1] << "\n";
            cout << "interactCheck = " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 2)[0] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 2)[1] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 2)[2] << "\n";
             */
            
            if (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 2)[0])
            {
                //cout << "interactCheck cross road = " << 2 << "\n";
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y);
                //cout << "situation 1" << "\n";
                
            }
            else if (spritePacman.getPosition().x == 0)
            {
                spritePacman.setPosition(641, spritePacman.getPosition().y);
            }
            else if (!interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 2)[3])
            {
                spritePacman.setPosition(spritePacman.getPosition().x - 0.25, pacmanPositionYArray[pacmanCoordinationRow - 1]);
                //cout << "situation 3" << "\n";
            }
            //else if (pacmanCoordinationColumn > (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 2)[2]))
            else
            {
                spritePacman.setPosition(spritePacman.getPosition().x - 0.25, spritePacman.getPosition().y);
                //cout << "situation 2" << "\n";
                
            }
            //cout << "\n";
        }
        
        if (!Keyboard::isKeyPressed(Keyboard::Right) && !Keyboard::isKeyPressed(Keyboard::Left) && Keyboard::isKeyPressed(Keyboard::Up) && !Keyboard::isKeyPressed(Keyboard::Down))
        {
            pacmanCoordinationRow = positionTranslate(23, 13, spritePacman.getPosition().x, spritePacman.getPosition().y)[0];
            pacmanCoordinationColumn = positionTranslate(23, 13, spritePacman.getPosition().x, spritePacman.getPosition().y)[1];
            /*
            cout << "Up " << "\n";
            cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
            cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n";
            
            cout << "pacmanCoordinationColumn = " << pacmanCoordinationColumn << "\n";
            cout << "pacmanCoordinationRow = " << pacmanCoordinationRow << "\n";
            
            cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
            cout << "Up is " << pacmanMap[pacmanCoordinationRow - 1][pacmanCoordinationColumn] << "\n";
            cout << "interactCheck = " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 3)[0] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 3)[1] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 3)[2] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 3)[3] << "\n";
             */
            
            if (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 3)[0])
            {
                //spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y - (pacmanSpeed * dt.asSeconds()));
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y);
                //cout << "situation 1" << "\n";
            }
            else if (!interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 3)[3])
            {
                spritePacman.setPosition(pacmanPositionXArray[pacmanCoordinationColumn - 1], spritePacman.getPosition().y - 0.25);
                //cout << "situation 3" << "\n";
            }
            else
            {
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y - 0.25);
                //cout << "situation 2" << "\n";
            }
            //cout << "\n";
        }
        
        if (!Keyboard::isKeyPressed(Keyboard::Right) && !Keyboard::isKeyPressed(Keyboard::Left) && !Keyboard::isKeyPressed(Keyboard::Up) && Keyboard::isKeyPressed(Keyboard::Down))
        {
            pacmanCoordinationRow = positionTranslate(23, 13, spritePacman.getPosition().x, spritePacman.getPosition().y)[0];
            pacmanCoordinationColumn = positionTranslate(23, 13, spritePacman.getPosition().x, spritePacman.getPosition().y)[1];
            /*
            cout << "Down " << "\n";
            cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
            cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n";
            
            cout << "pacmanCoordinationColumn = " << pacmanCoordinationColumn << "\n";
            cout << "pacmanCoordinationRow = " << pacmanCoordinationRow << "\n";
            
            cout << "pacmanPositionXArray[pacmanCoordinationColumn] = " << pacmanPositionXArray[pacmanCoordinationColumn - 1] << "\n";
            cout << "pacmanPositionYArray[pacmanCoordinationRow] = " << pacmanPositionYArray[pacmanCoordinationRow - 1] << "\n";
            
            cout << "situation3 condition 1 is " << (spritePacman.getPosition().x != pacmanPositionXArray[pacmanCoordinationColumn - 1]) << "\n";
            cout << "situation3 condition 2 is " << (spritePacman.getPosition().y != pacmanPositionYArray[pacmanCoordinationRow - 1]) << "\n";
            cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
            //cout << "Down is " << pacmanMap[pacmanCoordinationRow + 1][pacmanCoordinationColumn] << "\n";
            cout << "interactCheck = " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 4)[0] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 4)[1] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 4)[2] << "\n";
             */
            
            if (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 4)[0])
            {
                //spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y + (pacmanSpeed * dt.asSeconds()));
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y);
                //cout << "situation 1" << "\n";
            }
            else if (!interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, spritePacman.getPosition().x, spritePacman.getPosition().y, 4)[3])
            {
                spritePacman.setPosition(pacmanPositionXArray[pacmanCoordinationColumn - 1], spritePacman.getPosition().y + 0.25);
                //cout << "situation 3" << "\n";
            }
            else
            {
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y + 0.25);
                //cout << "situation 2" << "\n";
            }
            //cout << "\n";
        }
        
        if ((timePowerUpRemaining > 0) && (pacmanCoordinationRow == blueGhostCoordinationRow) && (pacmanCoordinationColumn == blueGhostCoordinationCol))
        {
            aliveBlueGhost = 0;
        }
        else if ((timePowerUpRemaining == 0) && (pacmanCoordinationRow == blueGhostCoordinationRow) && (pacmanCoordinationColumn == blueGhostCoordinationCol))
        {
            gameOver = 1;
        }
        
        //cout << "collectedCoins = " << collectedCoins << "\n";
        //if (collectedCoins == 240)
        if (collectedCoins == 10)
        {
            gameWin = 1;
            win.play();
        }
        
        if ((spritePacman.getPosition().x == 1000) && (spritePacman.getPosition().y == 0))
        {
            spriteBlueGhost.setPosition(1000, 0);
            spriteOrangeGhost.setPosition(1000, 0);
            spritePinkGhost.setPosition(1000, 0);
            spriteRedGhost.setPosition(1000, 0);
            
        }
        else if (!ghostActive)
        {
            // How fast is the cloud
            srand((int)time(0) * 10);
            ghostSpeed = (rand() % 200);
            randDirectionBlueGhost = rand() % 2;
            randDirectionOrangeGhost = rand() % 2;
            randDirectionPinkGhost = rand() % 2;
            randDirectionRedGhost = rand() % 2;
            
            spriteBlueGhost.setPosition(303, 246);
            spriteOrangeGhost.setPosition(303, 246);
            spritePinkGhost.setPosition(303, 246);
            spriteRedGhost.setPosition(303, 246);
            ghostActive = true;
        }
        
        else
        {
            //cout << "rand() % 2 = " << rand() % 2 << "\n";

            blueGhostCoordinationRow = ghostPositionTranslate(11, 13, spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y)[0];
            blueGhostCoordinationCol = ghostPositionTranslate(11, 13, spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y)[1];
            //cout << "randDirectionBlueGhost = " << randDirectionBlueGhost << "\n";
            //cout << "blueGhostCoordinationCol = " << blueGhostCoordinationCol << "\n";
            //cout << "blueGhostCoordinationRow = " << blueGhostCoordinationRow << "\n" << "\n";
            if (randDirectionBlueGhost == 0)
            {
                if (pacmanMap[blueGhostCoordinationRow][blueGhostCoordinationCol + 1] == 1)
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y);
                    randDirectionBlueGhost = rand() % 4;
                    //cout << "situation 1" << "\n";
                }
                else if (!interactCheck(pacmanMap, blueGhostCoordinationRow, blueGhostCoordinationCol, spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y, 1)[3])
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x + 0.2, pacmanPositionYArray[blueGhostCoordinationRow - 1]);
                }
                else
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x + 0.2, spriteBlueGhost.getPosition().y);
                }
            }
            if (randDirectionBlueGhost == 1)
            {
                if (pacmanMap[blueGhostCoordinationRow][blueGhostCoordinationCol - 1] == 1)
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y);
                    randDirectionBlueGhost = rand() % 4;
                    //cout << "situation 1" << "\n";
                }
                else if (!interactCheck(pacmanMap, blueGhostCoordinationRow, blueGhostCoordinationCol, spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y, 2)[3])
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x - 0.2, pacmanPositionYArray[blueGhostCoordinationRow - 1]);
                }
                else
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x - 0.2, spriteBlueGhost.getPosition().y);
                }
            }
            if (randDirectionBlueGhost == 2)
            {
                if (pacmanMap[blueGhostCoordinationRow - 1][blueGhostCoordinationCol] == 1)
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y);
                    randDirectionBlueGhost = rand() % 4;
                    //cout << "situation 1" << "\n";
                }
                else if (!interactCheck(pacmanMap, blueGhostCoordinationRow, blueGhostCoordinationCol, spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y, 3)[3])
                {
                    spriteBlueGhost.setPosition(pacmanPositionXArray[blueGhostCoordinationCol - 1], spriteBlueGhost.getPosition().y - 0.2);
                }
                else
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y - 0.2);
                }
            }
            if (randDirectionBlueGhost == 3)
            {
                if (pacmanMap[blueGhostCoordinationRow + 1][blueGhostCoordinationCol] == 1)
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y);
                    randDirectionBlueGhost = rand() % 4;
                    //cout << "situation 1" << "\n";
                }
                else if (!interactCheck(pacmanMap, blueGhostCoordinationRow, blueGhostCoordinationCol, spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y, 4)[3])
                {
                    spriteBlueGhost.setPosition(pacmanPositionXArray[blueGhostCoordinationCol - 1], spriteBlueGhost.getPosition().y + 0.2);
                }
                else
                {
                    spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y + 0.2);
                }
            }
            /*
            orangeGhostCoordinationRow = ghostPositionTranslate(11, 13, spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y)[0];
            orangeGhostCoordinationCol = ghostPositionTranslate(11, 13, spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y)[1];
            if (randDirectionOrangeGhost == 0)
            {
                if (pacmanMap[orangeGhostCoordinationRow][orangeGhostCoordinationCol + 1] == 1)
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y);
                    randDirectionOrangeGhost = rand() % 4;
                    //cout << "situation 1" << "\n";
                }
                else if (!interactCheck(pacmanMap, orangeGhostCoordinationRow, orangeGhostCoordinationCol, spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y, 1)[3])
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x + 0.2, pacmanPositionYArray[orangeGhostCoordinationRow - 1]);
                }
                else
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x + 0.2, spriteOrangeGhost.getPosition().y);
                }
            }
            if (randDirectionOrangeGhost == 1)
            {
                if (pacmanMap[orangeGhostCoordinationRow][orangeGhostCoordinationCol - 1] == 1)
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y);
                    randDirectionOrangeGhost = rand() % 4;
                    //cout << "situation 1" << "\n";
                }
                else if (!interactCheck(pacmanMap, orangeGhostCoordinationRow, orangeGhostCoordinationCol, spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y, 2)[3])
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x - 0.2, pacmanPositionYArray[orangeGhostCoordinationRow - 1]);
                }
                else
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x - 0.2, spriteOrangeGhost.getPosition().y);
                }
            }
            if (randDirectionOrangeGhost == 2)
            {
                if (pacmanMap[orangeGhostCoordinationRow - 1][orangeGhostCoordinationCol] == 1)
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y);
                    randDirectionOrangeGhost = rand() % 4;
                    //cout << "situation 1" << "\n";
                }
                else if (!interactCheck(pacmanMap, orangeGhostCoordinationRow, orangeGhostCoordinationCol, spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y, 3)[3])
                {
                    spriteOrangeGhost.setPosition(pacmanPositionXArray[orangeGhostCoordinationCol - 1], spriteOrangeGhost.getPosition().y - 0.2);
                }
                else
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y - 0.2);
                }
            }
            if (randDirectionOrangeGhost == 3)
            {
                if (pacmanMap[orangeGhostCoordinationRow + 1][orangeGhostCoordinationCol] == 1)
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y);
                    randDirectionOrangeGhost = rand() % 4;
                    //cout << "situation 1" << "\n";
                }
                else if (!interactCheck(pacmanMap, orangeGhostCoordinationRow, orangeGhostCoordinationCol, spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y, 4)[3])
                {
                    spriteOrangeGhost.setPosition(pacmanPositionXArray[orangeGhostCoordinationCol - 1], spriteOrangeGhost.getPosition().y + 0.2);
                }
                else
                {
                    spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x, spriteOrangeGhost.getPosition().y + 0.2);
                }
            }*/
            
            
            
            //spriteOrangeGhost.setPosition(spriteOrangeGhost.getPosition().x - (ghostSpeed * dt.asSeconds()), spriteOrangeGhost.getPosition().y);
            //spritePinkGhost.setPosition(spritePinkGhost.getPosition().x, spritePinkGhost.getPosition().y + (ghostSpeed * dt.asSeconds()));
            //spriteRedGhost.setPosition(spriteRedGhost.getPosition().x, spriteRedGhost.getPosition().y - (ghostSpeed * dt.asSeconds()));
        }
        
        /*
        ****************************************
        Update the scene
        ****************************************
        */

        // Clear screen
        window.clear();

        // Draw the sprite
        window.draw(spriteBackground);

        if (paused)
        {
            // Draw our message
            window.draw(messageText);
        }
        
        // Draw the pacman
        window.draw(spritePacman);
        
        // generate map
        //mapGenerate(window);
        if (!paused)
        {
            coinsManage(window, spritePacman.getPosition().x, spritePacman.getPosition().y);
        }
        //ghostManage(window, spritePacman.getPosition().x, spritePacman.getPosition().y, dt);
        
        //window.draw(spriteCoins);
        
        // Draw ghosts
        if (aliveBlueGhost)
        {
            window.draw(spriteBlueGhost);
        }
        if (aliveOrangeGhost)
        {
            window.draw(spriteOrangeGhost);
        }
        if (alivePinkGhost)
        {
            window.draw(spritePinkGhost);
        }
        if (aliveRedGhost)
        {
            window.draw(spriteRedGhost);
        }

        // Update the window
        window.display();
    }

    return EXIT_SUCCESS;
}
