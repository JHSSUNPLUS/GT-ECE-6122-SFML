//
//  positionTranslate.cpp
//  6122_SFML_Version3
//
//  Created by Jiahao Sun on 2022/10/21.
//  Copyright © 2022 Jiahao Sun. All rights reserved.
//

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <string>
#include <vector>
#include <numeric>
#include <cmath>
#include <math.h>
#include <iostream>

#include "globalVariable.h"

using namespace sf;
using namespace std;

int * ghostPositionTranslate(int initialRow, int initialCol, int pacmanPositionX, int pacmanPositionY)
{
    int pacmanPositionRow = initialRow;
    int pacmanPositionColumn = initialCol;
    static int interactResult[2] = {pacmanPositionRow, pacmanPositionColumn};
    
    //pacmanPositionRow = pacmanPositionY;
    //pacmanPositionColumn = pacmanPositionX;
    
    //pacmanPositionRow = (pacmanPositionY - 47) / 20;
    //pacmanPositionColumn = (pacmanPositionX - 37) / 21;

    /*
    if (pacmanPositionY is in pacmanPositionYArray, at i) // 40
    {
        pacmanPositionRow = pacmanPositionRowArray[i];
    }*/
    
    for (int i = 0; i < 29 + 1; i++)
    {
        
        if (pacmanPositionY == pacmanPositionYArray[i])
        {
            pacmanPositionRow = i + 1;
            interactResult[0] = pacmanPositionRow;
        }
    }
    
    for (int i = 0; i < 26 + 1; i++)
    {
        
        if (pacmanPositionX == pacmanPositionXArray[i])
        {
            pacmanPositionColumn = i + 1;
            interactResult[1] = pacmanPositionColumn;
        }
    }
    //interactResult[0] = pacmanPositionRow + 1;
    //interactResult[1] = pacmanPositionColumn + 1;
    
    return interactResult;
}

