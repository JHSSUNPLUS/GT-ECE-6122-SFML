//
//  ghostManage.cpp
//  6122_SFML_Version3
//
//  Created by Jiahao Sun on 2022/10/22.
//  Copyright © 2022 Jiahao Sun. All rights reserved.
//

#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <string>
#include <vector>
#include <numeric>
#include <cmath>
#include <math.h>
#include <iostream>

#include "globalVariable.h"
#include "interactCheck.cpp"
#include "ghostPositionTranslate.cpp"

using namespace sf;
using namespace std;

float * ghostManage(float ghostPositionX, float ghostPositionY)
{
    float ghostUpdatedPositionX;
    float ghostUpdatedPositionY;
    static float ghostOutput[2] = {ghostUpdatedPositionX, ghostUpdatedPositionY};
    
    blueGhostCoordinationRow = ghostPositionTranslate(11, 13, ghostPositionX, ghostPositionY)[0];
    blueGhostCoordinationCol = ghostPositionTranslate(11, 13, ghostPositionX, ghostPositionY)[1];
    
    //cout << "blueGhostCoordinationRow = " << blueGhostCoordinationRow << "\n";
    //cout << "blueGhostCoordinationCol = " << blueGhostCoordinationCol << "\n";
    //cout << "randDirectionBlueGhost = " << randDirectionBlueGhost << "\n";
    
    if (randDirectionBlueGhost == 0)
    {
        //cout << "pacmanMap[blueGhostCoordinationRow][blueGhostCoordinationCol + 1] = " << pacmanMap[blueGhostCoordinationRow][blueGhostCoordinationCol + 1] << "\n";
        if (pacmanMap[blueGhostCoordinationRow][blueGhostCoordinationCol + 1] == 1)
        {
            randDirectionBlueGhost = rand() % 4;
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y);
            ghostUpdatedPositionX = ghostPositionX;
            ghostUpdatedPositionY = ghostPositionY;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 1" << "\n";
            return ghostOutput;
        }
        else if (!interactCheck(pacmanMap, blueGhostCoordinationRow, blueGhostCoordinationCol, ghostPositionX, ghostPositionY, 1)[3])
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x + 0.2, pacmanPositionYArray[blueGhostCoordinationRow - 1]);
            ghostUpdatedPositionX = ghostPositionX + 0.2;
            ghostUpdatedPositionY = pacmanPositionYArray[blueGhostCoordinationRow - 1];
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 2" << "\n";
            //cout << "ghostUpdatedPositionX = " << ghostUpdatedPositionX << "\n";
            //cout << "ghostUpdatedPositionY = " << ghostUpdatedPositionY << "\n";
            return ghostOutput;
        }
        else
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x + 0.2, spriteBlueGhost.getPosition().y);
            ghostUpdatedPositionX = ghostPositionX + 0.2;
            ghostUpdatedPositionY = ghostPositionY;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 3" << "\n";
            return ghostOutput;
        }
    }
    if (randDirectionBlueGhost == 1)
    {
        if (pacmanMap[blueGhostCoordinationRow][blueGhostCoordinationCol - 1] == 1)
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y);
            randDirectionBlueGhost = rand() % 4;
            //cout << "situation 1" << "\n";
            ghostUpdatedPositionX = ghostPositionX;
            ghostUpdatedPositionY = ghostPositionY;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 4" << "\n";
            return ghostOutput;
        }
        else if (!interactCheck(pacmanMap, blueGhostCoordinationRow, blueGhostCoordinationCol, ghostPositionX, ghostPositionY, 2)[3])
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x - 0.2, pacmanPositionYArray[blueGhostCoordinationRow - 1]);
            ghostUpdatedPositionX = ghostPositionX - 0.2;
            ghostUpdatedPositionY = pacmanPositionYArray[blueGhostCoordinationRow - 1];
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 5" << "\n";
            return ghostOutput;
        }
        else
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x - 0.2, spriteBlueGhost.getPosition().y);
            ghostUpdatedPositionX = ghostPositionX - 0.2;
            ghostUpdatedPositionY = ghostPositionY;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 6" << "\n";
            return ghostOutput;
        }
    }
    if (randDirectionBlueGhost == 2)
    {
        if (pacmanMap[blueGhostCoordinationRow - 1][blueGhostCoordinationCol] == 1)
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y);
            randDirectionBlueGhost = rand() % 4;
            //cout << "situation 1" << "\n";
            ghostUpdatedPositionX = ghostPositionX;
            ghostUpdatedPositionY = ghostPositionY;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            return ghostOutput;
        }
        else if (!interactCheck(pacmanMap, blueGhostCoordinationRow, blueGhostCoordinationCol, ghostPositionX, ghostPositionY, 3)[3])
        {
            //spriteBlueGhost.setPosition(pacmanPositionXArray[blueGhostCoordinationCol - 1], spriteBlueGhost.getPosition().y - 0.2);
            ghostUpdatedPositionX = pacmanPositionXArray[blueGhostCoordinationCol - 1];
            ghostUpdatedPositionY = ghostPositionY - 0.2;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            return ghostOutput;
        }
        else
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y - 0.2);
            ghostUpdatedPositionX = ghostPositionX;
            ghostUpdatedPositionY = ghostPositionY - 0.2;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            return ghostOutput;
        }
    }
    if (randDirectionBlueGhost == 3)
    {
        //cout << "pacmanMap[blueGhostCoordinationRow + 1][blueGhostCoordinationCol] = " << pacmanMap[blueGhostCoordinationRow + 1][blueGhostCoordinationCol] << "\n";
        if (pacmanMap[blueGhostCoordinationRow + 1][blueGhostCoordinationCol] == 1)
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y);
            randDirectionBlueGhost = rand() % 4;
            //cout << "situation 1" << "\n";
            ghostUpdatedPositionX = ghostPositionX;
            ghostUpdatedPositionY = ghostPositionY;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 5" << "\n";
            return ghostOutput;
        }
        else if (!interactCheck(pacmanMap, blueGhostCoordinationRow, blueGhostCoordinationCol, ghostPositionX, ghostPositionY, 4)[3])
        {
            //spriteBlueGhost.setPosition(pacmanPositionXArray[blueGhostCoordinationCol - 1], spriteBlueGhost.getPosition().y + 0.2);
            ghostUpdatedPositionX = pacmanPositionXArray[blueGhostCoordinationCol - 1];
            ghostUpdatedPositionY = ghostPositionY + 0.2;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 6" << "\n";
            //cout << "ghostUpdatedPositionX = " << ghostUpdatedPositionX << "\n";
            //cout << "ghostUpdatedPositionY = " << ghostUpdatedPositionY << "\n";
            return ghostOutput;
        }
        else
        {
            //spriteBlueGhost.setPosition(spriteBlueGhost.getPosition().x, spriteBlueGhost.getPosition().y + 0.2);
            ghostUpdatedPositionX = ghostPositionX;
            ghostUpdatedPositionY = ghostPositionY + 0.2;
            ghostOutput[0] = ghostUpdatedPositionX;
            ghostOutput[1] = ghostUpdatedPositionY;
            //cout << "Enter Here 7" << "\n";
            return ghostOutput;
        }
    }
    
    return ghostOutput;
}
