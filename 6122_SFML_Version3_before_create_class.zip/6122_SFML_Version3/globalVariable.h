//
//  globalVariable.h
//  6122_SFML_Version3
//
//  Created by Jiahao Sun on 2022/10/21.
//  Copyright © 2022 Jiahao Sun. All rights reserved.
//
#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <numeric>
#include <cmath>
#include <sstream>
#include <thread>
#include <chrono>
#include <ctime>
#include <fstream>
#include <math.h>
using namespace sf;
using namespace std;

#ifndef globalVariable_h
#define globalVariable_h

vector<vector<int> > pacmanMap;
int pacmanCoordinationRow = 23; // Row
int pacmanCoordinationColumn = 13; // Column
int rowNumber = 28;
int columnNumber = 31;

int blueGhostCoordinationRow = 11;
int blueGhostCoordinationCol = 13;
int orangeGhostCoordinationRow = 11;
int orangeGhostCoordinationCol = 13;

// Used in positionTranslate
//old version
//static int pacmanPositionXArray[26] = {43, 62, 82, 102, 121, /*1 - 5*/
//                                       141, 161, 180, 200, 220, /*6 - 10*/
//                                       239, 259, 279, 299, 318, /*11 - 15*/
//                                       338, 358, 377, 397, 417, /*16 - 20*/
//                                       436, 456, 476, 495, 515, /*21 - 25*/
//                                       535}; // 1 ~ 26
static int pacmanPositionXArray[26] = {43, 65, 82, 102, 124, /*1 - 5*/
                                       147, 167, 187, 210, 231, /*6 - 10*/
                                       250, 270, 291, 312, 332, /*11 - 15*/
                                       354, 373, 394, 414, 436, /*16 - 20*/
                                       452, 476, 494, 515, 530, /*21 - 25*/
                                       558}; // 1 ~ 26
static int pacmanPositionColumnArray[26]; // 1 ~ 26

//static int pacmanPositionYArray[29] = {40, 59, 79, 99, 118, /*1 - 5*/
//                                       138, 158, 177, 197, 217, /*6 - 10*/
//                                       236, 256, 276, 296, 315, /*11 - 15*/
//                                       335, 355, 374, 394, 414, /*16 - 20*/
//                                       433, 453, 473, 492, 512, /*21 - 25*/
//                                       532, 552, 571, 591}; // 1 ~ 29
static int pacmanPositionYArray[29] = {40, 63, 80, 102, 121, /*1 - 5*/
                                       146, 161, 184, 205, 221, /*6 - 10*/
                                       247, 265, 286, 306, 328, /*11 - 15*/
                                       348, 368, 389, 408, 430, /*16 - 20*/
                                       454, 467, 492, 513, 529, /*21 - 25*/
                                       553, 575, 593, 614}; // 1 ~ 29
static int pacmanPositionRowArray[29]; // 1 ~ 29

bool ghostActive = false;

float ghostSpeed = 0.0f;

int randDirectionBlueGhost;
int randDirectionOrangeGhost;
int randDirectionPinkGhost;
int randDirectionRedGhost;

bool aliveBlueGhost = true;
bool aliveOrangeGhost = true;
bool alivePinkGhost = true;
bool aliveRedGhost = true;

bool gameOver = false;
bool gameWin = false;

float timePowerUpRemaining = 0;

int collectedCoins = 0;

#endif /* globalVariable_h */
