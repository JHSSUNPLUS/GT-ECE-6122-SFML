//
//  coinsManage.cpp
//  6122_SFML_Version3
//
//  Created by Jiahao Sun on 2022/10/21.
//  Copyright © 2022 Jiahao Sun. All rights reserved.
//

#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <string>
#include <vector>
#include <numeric>
#include <cmath>
#include <math.h>
#include <iostream>

#include "globalVariable.h"

using namespace sf;
using namespace std;

int * coinsManage(sf::RenderWindow& gameWindow, int pacmanPositionX, int pacmanPositionY)
{
    int message1;
    int message2;
    static int coinsOutput[2] = {message1, message2};
    
    //pacmanMap = mapGenerate();
    
    
    sf::CircleShape shape(2.f);
    shape.setFillColor(sf::Color::White);
    //shape.setPosition(pacmanPositionXArray[1], pacmanPositionYArray[1]);
    sf::CircleShape shape2(5.f);
    shape2.setFillColor(sf::Color::White);
    
    sf::CircleShape shape3(2.f);
    shape3.setFillColor(sf::Color::Green);
    //shape3.setPosition(43, 40);
    shape3.setPosition(pacmanPositionXArray[0], pacmanPositionYArray[0]);
    gameWindow.draw(shape3);
    shape3.setPosition(pacmanPositionXArray[0], pacmanPositionYArray[1]);
    gameWindow.draw(shape3);
    
    for(int row = 1; row < 30; row++)
    {
        // make a
        for(int col = 1; col < 27; col++)
        {
            if ((pacmanPositionX == pacmanPositionXArray[col - 1]) && (pacmanPositionY == pacmanPositionYArray[row - 1]))
            {
                pacmanMap[row][col] = 2;
            }
            else if (pacmanMap[row][col] == 0)
            {
                shape.setFillColor(sf::Color::White);
                shape.setPosition(pacmanPositionXArray[col - 1] + 15, pacmanPositionYArray[row - 1] + 15);
                gameWindow.draw(shape);
            }
            else if (pacmanMap[row][col] == 3)
            {
                shape2.setFillColor(sf::Color::White);
                shape2.setPosition(pacmanPositionXArray[col - 1] + 15, pacmanPositionYArray[row - 1] + 15);
                gameWindow.draw(shape2);
            }
        }
    }
    
    /*
    for(int col = 1; col < 27; col++)
    {
        if (pacmanMap[29][col] == 0){
            shape.setFillColor(sf::Color::White);
            shape.setPosition(pacmanPositionXArray[col], pacmanPositionYArray[28]);
            gameWindow.draw(shape);
        }
        else if (pacmanMap[29][col] == 3)
        {
            shape2.setFillColor(sf::Color::White);
            shape2.setPosition(pacmanPositionXArray[col], pacmanPositionYArray[28]);
            gameWindow.draw(shape2);
        }
    }
    
    for(int row = 1; row < 30; row++)
    {
        if (pacmanMap[row][26] == 0){
            shape.setFillColor(sf::Color::White);
            shape.setPosition(pacmanPositionXArray[25], pacmanPositionYArray[row]);
            gameWindow.draw(shape);
        }
        else if (pacmanMap[row][26] == 3)
        {
            shape2.setFillColor(sf::Color::White);
            shape2.setPosition(pacmanPositionXArray[25], pacmanPositionYArray[row]);
            gameWindow.draw(shape2);
        }
    }*/
    
    return coinsOutput;
}
