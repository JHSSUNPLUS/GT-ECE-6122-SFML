/*
Author: Jiahao Sun
Class: ECE6122 QSZ
Last Date Modified: 10/17/2022
Description:
 This is a Pacman Game
 
 • Display the provided pac-man.bmp at the start of the game with the extra text
     o PRESS ENTER TO START
  in the middle of the window.
 • Once the user presses the ENTER key the game starts with
     o pacman located as shown above
     o all four ghosts start at the same location as shown above (bitmaps provided)
     o place the four power ups as shown above
     o place the coins as shown above
 
 • The ghost’s initial direction is determined randomly and when a ghost hits a wall
 its new direction is chosen randomly.
 • Control the location of pacman using the left, right, up, down arrow keys. • (~10 pts) Determine a game speed that makes the game fun to play (not too slow and not to
 fast)
 • The game ends when
     o one of the ghosts comes in contact with a non-powered up pacman
     o pacman consumes all the coins
     o user presses the escape key.
 • When pacman eats a powerup he can eat ghosts for 5 seconds. Ghosts that are
 eaten are gone forever.
 • Pacman and the ghost cannot go through walls.
 • Pacman and the ghost can go through the middle tunnels on each side.
 • You do not have to handle resizing the window. Just use the image size.
*/

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <ctime>
#include <numeric>
#include <cmath>
#include <sstream>
#include <thread>
#include <chrono>
#include <ctime>
#include <fstream>
#include <math.h>

using namespace sf;
using namespace std;

#include "globalVariable.h"
#include "mapGenerate.cpp"
#include "interactCheck.cpp"
#include "positionTranslate.cpp"



int main(int argc, char const** argv)
{
    // Create the main window
    //sf::RenderWindow window(sf::VideoMode(641, 728), "SFML window");
    sf::RenderWindow window(sf::VideoMode(1600, 1800), "SFML window");

    // Track whether the game is running
    bool paused = true;

    // Load a sprite to display
    sf::Texture textureBackground;
    if (!textureBackground.loadFromFile("graphics/maze.bmp"))
    {
        return EXIT_FAILURE;
    }
    
    /*
    constexpr unsigned char CELL_SIZE = 16;
    Sprite spriteCoins;
    spriteCoins.setTextureRect(sf::IntRect(0, CELL_SIZE, CELL_SIZE, CELL_SIZE));
     */
    
    // Create a sprite
    sf::Sprite spriteBackground;
    
    // Attach the texture to the sprite
    spriteBackground.setTexture(textureBackground);

    // Set the spriteBackground to cover the screen
    spriteBackground.setPosition(0, 0);

    // Make a pacman sprite
    Texture texturePacman;
    texturePacman.loadFromFile("graphics/pacman.bmp");
    Sprite spritePacman;
    spritePacman.setTexture(texturePacman);
    spritePacman.setPosition(1000, 0);
    
    // Is the pacman currently moving?
    bool pacmanActive = false;

    // How fast can the pacman run
    float pacmanSpeed = 0.0f;

    // Prepare the blue ghost
    Texture textureBlueGhost;
    textureBlueGhost.loadFromFile("graphics/blue_ghost.bmp");
    Sprite spriteBlueGhost;
    spriteBlueGhost.setTexture(textureBlueGhost);
    spriteBlueGhost.setPosition(1000, 0);
    
    // Prepare the orange ghost
    Texture textureOrangeGhost;
    textureOrangeGhost.loadFromFile("graphics/orange_ghost.bmp");
    Sprite spriteOrangeGhost;
    spriteOrangeGhost.setTexture(textureOrangeGhost);
    spriteOrangeGhost.setPosition(1000, 0);
    
    // Prepare the pink ghost
    Texture texturePinkGhost;
    texturePinkGhost.loadFromFile("graphics/pink_ghost.bmp");
    Sprite spritePinkGhost;
    spritePinkGhost.setTexture(texturePinkGhost);
    spritePinkGhost.setPosition(1000, 0);
    
    // Prepare the red ghost
    Texture textureRedGhost;
    textureRedGhost.loadFromFile("graphics/red_ghosts.bmp");
    Sprite spriteRedGhost;
    spriteRedGhost.setTexture(textureRedGhost);
    spriteRedGhost.setPosition(1000, 0);
    
    // Show PRESS ENTER TO START text
    sf::Text messageText;
    sf::Text scoreText;

    // We need to choose a font
    sf::Font font;
    font.loadFromFile("sansation.ttf");

    // Set the font to our message
    messageText.setFont(font);
    scoreText.setFont(font);

    // Assign the actual message
    messageText.setString("PRESS ENTER TO START");
    scoreText.setString("Score = 0");

    // Make it really big
    messageText.setCharacterSize(40);
    scoreText.setCharacterSize(40);

    // Choose a color
    messageText.setFillColor(Color::White);
    scoreText.setFillColor(Color::White);

    // Position the text
    FloatRect textRect = messageText.getLocalBounds();

    messageText.setOrigin(textRect.left +
        textRect.width / 2.0f,
        textRect.top +
        textRect.height / 2.0f);

    messageText.setPosition(320 / 1.0f, 360 / 1.0f);
    
    // Variables to control time itself
    Clock clock;
    
    Time dt = clock.restart();
    pacmanSpeed = 100;
    
    // Map related parameter preparation
    // Generate map in vector
    pacmanMap = mapGenerate();
    
    /*
    for(int i = 1; i < 26 + 1; i++)
    {
        pacmanPositionXArray[i - 1] = 43 + (i - 1) * (555 - 43) / 26;
        cout << pacmanPositionXArray[i - 1] << ", ";
    }
    cout << "\n";
    
    for(int i = 1; i < 26 + 1; i++)
    {
        pacmanPositionColumnArray[i - 1] = i;
        cout << pacmanPositionColumnArray[i - 1] << ", ";
    }
    cout << "\n";
    
    for(int i = 1; i < 29 + 1; i++)
    {
        pacmanPositionYArray[i - 1] = 40 + (i - 1) * (555 - 43) / 26;
        cout << pacmanPositionYArray[i - 1] << ", ";
    }
    cout << "\n";
    
    for(int i = 1; i < 29 + 1; i++)
    {
        pacmanPositionRowArray[i - 1] = i;
        cout << pacmanPositionRowArray[i - 1] << ", ";
    }
    cout << "\n";
    */
    
    cout << "pacmanPositionXArray[5] = " << pacmanPositionXArray[5] << "\n";
    cout << "pacmanPositionXArray[6] = " << pacmanPositionXArray[6] << "\n";
    cout << "pacmanPositionXArray[7] = " << pacmanPositionXArray[7] << "\n";

    // Start the game loop
    while (window.isOpen())
    {
        // Process events
        sf::Event event;
        while (window.pollEvent(event))
        {
            // Close window: exit
            if (event.type == sf::Event::Closed) {
                window.close();
            }

            // Escape pressed: exit
            if (event.type == sf::Event::KeyPressed && event.key.code == sf::Keyboard::Escape) {
                window.close();
            }
        }
        
        /*
        ****************************************
        Handle the players input
        ****************************************
        */
        // Start the game
        if (Keyboard::isKeyPressed(Keyboard::Return))
        {
            paused = false;

            // Reset the time and the score
            //score = 0;
            //timeRemaining = 6;

            // pacman initial position
            //spritePacman.setPosition(321 - 18, 364 - 17 + 145);
            spritePacman.setPosition(303, 492);

            // ghosts initial position
            spriteBlueGhost.setPosition(321 - 18, 364 - 17 - 101);
            spriteOrangeGhost.setPosition(321 - 18, 364 - 17 - 101);
            spritePinkGhost.setPosition(321 - 18, 364 - 17 - 101);
            spriteRedGhost.setPosition(321 - 18, 364 - 17 - 101);

            //acceptInput = true;
        }

        //cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
        //cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n" << "\n";
        
        //cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
        
        if (Keyboard::isKeyPressed(Keyboard::Right) && !Keyboard::isKeyPressed(Keyboard::Left) && !Keyboard::isKeyPressed(Keyboard::Up) && !Keyboard::isKeyPressed(Keyboard::Down))
        {
            
            pacmanCoordinationRow = positionTranslate(spritePacman.getPosition().x, spritePacman.getPosition().y)[0];
            pacmanCoordinationColumn = positionTranslate(spritePacman.getPosition().x, spritePacman.getPosition().y)[1];

            cout << "Right " << "\n";
            cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
            cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n";
            
            cout << "pacmanCoordinationColumn = " << pacmanCoordinationColumn << "\n";
            cout << "pacmanCoordinationRow = " << pacmanCoordinationRow << "\n";
            
            cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
            cout << "Right is " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn + 1] << "\n";
            cout << "interactCheck = " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 1)[0] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 1)[1] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 1)[2] << "\n";
            
            if (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 1)[0])
            {
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y);
                cout << "situation 1" << "\n";
            }
            //else if ((interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 1)[2] - pacmanCoordinationColumn) > 0)
            else
            {
                spritePacman.setPosition(spritePacman.getPosition().x + 0.25, spritePacman.getPosition().y);
                
                cout << "situation 2" << "\n";
            }
            cout << "\n";
        }
        
        if (!Keyboard::isKeyPressed(Keyboard::Right) && Keyboard::isKeyPressed(Keyboard::Left) && !Keyboard::isKeyPressed(Keyboard::Up) && !Keyboard::isKeyPressed(Keyboard::Down))
        {
            pacmanCoordinationRow = positionTranslate(spritePacman.getPosition().x, spritePacman.getPosition().y)[0];
            pacmanCoordinationColumn = positionTranslate(spritePacman.getPosition().x, spritePacman.getPosition().y)[1];
            
            cout << "Left " << "\n";
            cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
            cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n";
            
            cout << "pacmanCoordinationColumn = " << pacmanCoordinationColumn << "\n";
            cout << "pacmanCoordinationRow = " << pacmanCoordinationRow << "\n";
            
            cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
            cout << "Left is " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn - 1] << "\n";
            cout << "interactCheck = " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 2)[0] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 2)[1] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 2)[2] << "\n";
            
            if (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 2)[0])
            {
                //cout << "interactCheck cross road = " << 2 << "\n";
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y);
                cout << "situation 1" << "\n";
                
            }
            //else if (pacmanCoordinationColumn > (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 2)[2]))
            else
            {
                spritePacman.setPosition(spritePacman.getPosition().x - 0.25, spritePacman.getPosition().y);
                cout << "situation 2" << "\n";
                
            }
            cout << "\n";
        }
        
        if (!Keyboard::isKeyPressed(Keyboard::Right) && !Keyboard::isKeyPressed(Keyboard::Left) && Keyboard::isKeyPressed(Keyboard::Up) && !Keyboard::isKeyPressed(Keyboard::Down))
        {
            pacmanCoordinationRow = positionTranslate(spritePacman.getPosition().x, spritePacman.getPosition().y)[0];
            pacmanCoordinationColumn = positionTranslate(spritePacman.getPosition().x, spritePacman.getPosition().y)[1];
            cout << "Up " << "\n";
            cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
            cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n";
            
            cout << "pacmanCoordinationColumn = " << pacmanCoordinationColumn << "\n";
            cout << "pacmanCoordinationRow = " << pacmanCoordinationRow << "\n";
            
            cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
            cout << "Up is " << pacmanMap[pacmanCoordinationRow - 1][pacmanCoordinationColumn] << "\n";
            cout << "interactCheck = " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 3)[0] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 3)[1] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 3)[2] << "\n";
            
            if (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 3)[0])
            {
                //spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y - (pacmanSpeed * dt.asSeconds()));
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y);
                cout << "situation 1" << "\n";
            }
            //else if (pacmanCoordinationRow < (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 3)[2]))
            else
            {
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y - 0.25);
                cout << "situation 2" << "\n";
            }
            cout << "\n";
        }
        
        if (!Keyboard::isKeyPressed(Keyboard::Right) && !Keyboard::isKeyPressed(Keyboard::Left) && !Keyboard::isKeyPressed(Keyboard::Up) && Keyboard::isKeyPressed(Keyboard::Down))
        {
            pacmanCoordinationRow = positionTranslate(spritePacman.getPosition().x, spritePacman.getPosition().y)[0];
            pacmanCoordinationColumn = positionTranslate(spritePacman.getPosition().x, spritePacman.getPosition().y)[1];
            cout << "Down " << "\n";
            cout << "spritePacman.getPosition().x = " << spritePacman.getPosition().x << "\n";
            cout << "spritePacman.getPosition().y = " << spritePacman.getPosition().y << "\n";
            
            cout << "pacmanCoordinationColumn = " << pacmanCoordinationColumn << "\n";
            cout << "pacmanCoordinationRow = " << pacmanCoordinationRow << "\n";
            
            cout << "pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] = " << pacmanMap[pacmanCoordinationRow][pacmanCoordinationColumn] << "\n";
            cout << "Down is " << pacmanMap[pacmanCoordinationRow + 1][pacmanCoordinationColumn] << "\n";
            cout << "interactCheck = " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 4)[0] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 4)[1] << " " << interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 4)[2] << "\n";
            
            if (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 4)[0])
            {
                //spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y + (pacmanSpeed * dt.asSeconds()));
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y);
                cout << "situation 1" << "\n";
            }
            //else if (pacmanCoordinationRow > (interactCheck(pacmanMap, pacmanCoordinationRow, pacmanCoordinationColumn, 4)[2]))
            else
            {
                spritePacman.setPosition(spritePacman.getPosition().x, spritePacman.getPosition().y + 0.25);
                cout << "situation 2" << "\n";
            }
            cout << "\n";
        }
        
        /*
        ****************************************
        Update the scene
        ****************************************
        */

        // Clear screen
        window.clear();

        // Draw the sprite
        window.draw(spriteBackground);

        if (paused)
        {
            // Draw our message
            window.draw(messageText);
        }
        
        // Draw the pacman
        window.draw(spritePacman);
        
        // Draw ghosts
        window.draw(spriteBlueGhost);
        
        window.draw(spriteOrangeGhost);
        
        window.draw(spritePinkGhost);
        
        window.draw(spriteRedGhost);
        
        // generate map
        //mapGenerate(window);
        
        //window.draw(spriteCoins);

        // Update the window
        window.display();
    }

    return EXIT_SUCCESS;
}
