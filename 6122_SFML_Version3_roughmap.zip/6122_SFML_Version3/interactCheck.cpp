//
//  interactCheck.cpp
//  6122_Lab3_2D_Graphics_&_SMFL
//
//  Created by Jiahao Sun on 2022/10/18.
//  Copyright © 2022 Jiahao Sun. All rights reserved.
//

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <string>
#include <vector>
#include <numeric>
#include <cmath>
#include <math.h>
#include <iostream>

using namespace sf;
using namespace std;

int * interactCheck(vector<vector<int> > mapVec, int pacmanPositionRow, int pacmanPositionColumn, int pressedKey)
{
    /*
    int pacmanPixelFloorPositionX = floor(pacmanPositionX);
    int pacmanPixelFloorPositionY = floor(pacmanPositionY);
    int pacmanPixelCeilPositionX = ceil(pacmanPositionX);
    int pacmanPixelCeilPositionY = ceil(pacmanPositionY);*/
    int wall = 1;
    int updatedPacmanPositionRow = pacmanPositionRow;
    int updatedPacmanPositionColumn = pacmanPositionColumn;
    static int interactResult[3] = {wall, updatedPacmanPositionRow, updatedPacmanPositionColumn};
    
    // if interact with wall
    // Use case not if
    switch (pressedKey)
    {
            // Find a wall forward
        case 1:
        {
            //cout << "mapVec[pacmanPositionRow][pacmanPositionColumn + 1] = " << mapVec[pacmanPositionRow][pacmanPositionColumn + 1] << "\n";
            if (mapVec[pacmanPositionRow][pacmanPositionColumn + 1] == 1)
            {
                wall = 1;
                interactResult[0] = wall;
                return interactResult; // Cannot go right
            }
            else
            {
                wall = 0;
                updatedPacmanPositionColumn = updatedPacmanPositionColumn + 1;
                interactResult[0] = wall;
                interactResult[2] = updatedPacmanPositionColumn;
                return interactResult;
            }
        }
        case 2:
        {
            if (mapVec[pacmanPositionRow][pacmanPositionColumn - 1] == 1)
            {
                wall = 1;
                interactResult[0] = wall;
                return interactResult; // Cannot go left
            }
            else
            {
                wall = 0;
                updatedPacmanPositionColumn = updatedPacmanPositionColumn - 1;
                interactResult[0] = wall;
                interactResult[2] = updatedPacmanPositionColumn;
                return interactResult;
            }
        }
        case 3:
        {
            if (mapVec[pacmanPositionRow - 1][pacmanPositionColumn] == 1)
            {
                wall = 1;
                interactResult[0] = wall;
                return interactResult; // Cannot go up
            }
            else
            {
                wall = 0;
                updatedPacmanPositionRow = updatedPacmanPositionRow - 1;
                interactResult[0] = wall;
                interactResult[1] = updatedPacmanPositionRow;
                return interactResult;
            }
        }
        case 4:
        {
            if (mapVec[pacmanPositionRow + 1][pacmanPositionColumn] == 1)
            {
                wall = 1;
                interactResult[0] = wall;
                return interactResult; // Cannot go down
            }
            else
            {
                wall = 0;
                updatedPacmanPositionRow = updatedPacmanPositionRow + 1;
                interactResult[0] = wall;
                interactResult[1] = updatedPacmanPositionRow;
                return interactResult;
            }
        }
    }
    return 0;
}
