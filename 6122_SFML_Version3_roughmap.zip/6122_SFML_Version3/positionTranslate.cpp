//
//  positionTranslate.cpp
//  6122_SFML_Version3
//
//  Created by Jiahao Sun on 2022/10/21.
//  Copyright © 2022 Jiahao Sun. All rights reserved.
//

#include <SFML/Audio.hpp>
#include <SFML/Graphics.hpp>
#include <cstdlib>
#include <string>
#include <vector>
#include <numeric>
#include <cmath>
#include <math.h>
#include <iostream>

#include "globalVariable.h"

using namespace sf;
using namespace std;

int * positionTranslate(int pacmanPositionX, int pacmanPositionY)
{
    int pacmanPositionRow = 23;
    int pacmanPositionColumn = 13;
    static int interactResult[2] = {pacmanPositionRow, pacmanPositionColumn};
    
    //pacmanPositionRow = pacmanPositionY;
    //pacmanPositionColumn = pacmanPositionX;
    
    //pacmanPositionRow = (pacmanPositionY - 47) / 20;
    //pacmanPositionColumn = (pacmanPositionX - 37) / 21;

    /*
    if (pacmanPositionY is in pacmanPositionYArray, at i) // 40
    {
        pacmanPositionRow = pacmanPositionRowArray[i];
    }*/
    
    for (int i = 0; i < 29 + 1; i++)
    {
        
        if (pacmanPositionY == pacmanPositionYArray[i])
        {
            interactResult[0] = i + 1;
        }
    }
    
    for (int i = 0; i < 26 + 1; i++)
    {
        
        if (pacmanPositionX == pacmanPositionXArray[i])
        {
            interactResult[1] = i + 1;
        }
    }
    //interactResult[0] = pacmanPositionRow + 1;
    //interactResult[1] = pacmanPositionColumn + 1;
    
    return interactResult;
}
